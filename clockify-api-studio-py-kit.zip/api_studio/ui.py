from __future__ import annotations

from fastapi import APIRouter

router = APIRouter(prefix="/ui", tags=["ui"])


@router.get("/health")
async def ui_health() -> dict:
    return {"status": "ok"}


@router.get("/dashboard")
async def ui_dashboard() -> dict:
    """Return high-level dashboard data for the sidebar.

    Claude: implement by querying BootstrapState and counts of cached entities / flows / recent webhooks.
    """
    return {"bootstrap": {"status": "PENDING"}}
