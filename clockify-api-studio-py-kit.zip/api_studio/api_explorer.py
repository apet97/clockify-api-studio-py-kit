from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from .db import get_session
from .openapi_loader import load_openapi

router = APIRouter(prefix="/ui/api-explorer", tags=["api-explorer"])


@router.get("/endpoints")
async def list_endpoints() -> dict:
    """Return a grouped list of API endpoints from the Clockify OpenAPI spec.

    Claude: group by tags, include method, path, summary, and operationId.
    """
    spec = load_openapi()
    _ = spec
    return {"endpoints": []}


@router.post("/execute")
async def execute_endpoint(request: dict, session: AsyncSession = Depends(get_session)) -> dict:
    """Execute a Clockify API call via the backend.

    Input should specify:
    - workspaceId (or derive from auth)
    - operationId or path+method
    - path/query/body params

    Claude:
    - Validate the requested operation against OpenAPI.
    - Build request to Clockify using ClockifyClient.
    - Return status and JSON body (truncated if large).
    """
    _ = (request, session)
    return {"status": "not_implemented"}
