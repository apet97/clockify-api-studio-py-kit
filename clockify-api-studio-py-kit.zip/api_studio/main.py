from __future__ import annotations

from fastapi import FastAPI

from . import lifecycle, webhooks, api_explorer, ui


def create_app() -> FastAPI:
    app = FastAPI(title="Clockify API Studio", version="0.1.0")

    app.include_router(lifecycle.router)
    app.include_router(webhooks.router)
    app.include_router(api_explorer.router)
    app.include_router(ui.router)

    @app.get("/healthz")
    async def healthz() -> dict:
        return {"status": "ok"}

    return app


app = create_app()
