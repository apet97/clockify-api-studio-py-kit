from __future__ import annotations

from typing import Any, Dict, List

from sqlalchemy.ext.asyncio import AsyncSession

from .clockify_client import ClockifyClient
from .models import Flow, FlowExecution, WebhookLog


async def evaluate_and_run_flows_for_webhook(
    session: AsyncSession,
    workspace_id: str,
    webhook: WebhookLog,
    client: ClockifyClient,
) -> None:
    """Evaluate all flows for this webhook and run matching actions.

    High-level algorithm (see docs/FLOW_EXAMPLES_API_STUDIO.md):
    - Load enabled flows for workspace_id where trigger_event_types contains webhook.event_type.
    - For each flow, evaluate conditions against webhook.payload.
    - For matching flows, execute actions sequentially via ClockifyClient.
    - Persist FlowExecution rows with status and truncated results.

    Claude: implement this fully, including a small condition language and parameter mapping.
    """
    # TODO: query flows, evaluate conditions, run actions, persist executions.
    _ = (workspace_id, webhook, client)
