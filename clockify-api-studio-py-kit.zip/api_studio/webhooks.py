from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from .db import get_session
from .models import WebhookLog

router = APIRouter(prefix="/webhooks", tags=["webhooks"])


@router.post("/clockify")
async def receive_clockify_webhook(payload: dict, session: AsyncSession = Depends(get_session)) -> dict:
    """Receive and log Clockify webhooks.

    Claude:
    - Validate authenticity (signature/JWT) according to Clockify_Addon_Guide.
    - Extract workspaceId and eventType.
    - Persist WebhookLog.
    - Invoke flows.evaluate_and_run_flows_for_webhook.
    """
    _ = (payload, session)
    return {"status": "received"}
