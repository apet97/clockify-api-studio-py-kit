from __future__ import annotations

from typing import Any, Dict

import httpx
from tenacity import AsyncRetrying, retry_if_exception_type, stop_after_attempt, wait_exponential

from .config import settings


class ClockifyClientError(Exception):
    pass


class ClockifyClient:
    def __init__(self, base_url: str, addon_token: str) -> None:
        self.base_url = base_url.rstrip("/")
        self.addon_token = addon_token

    async def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        url = f"{self.base_url.rstrip('/')}/{path.lstrip('/')}"
        headers: Dict[str, str] = kwargs.pop("headers", {})
        headers["X-Addon-Token"] = self.addon_token

        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(5),
            wait=wait_exponential(multiplier=0.5, min=0.5, max=8),
            retry=retry_if_exception_type(httpx.HTTPStatusError),
            reraise=True,
        ):
            with attempt:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    resp = await client.request(method=method, url=url, headers=headers, **kwargs)
                    if resp.status_code == 429:
                        # Raise to trigger retry/backoff
                        raise httpx.HTTPStatusError("Rate limited", request=resp.request, response=resp)
                    return resp

    async def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self._request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self._request("POST", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self._request("PUT", path, **kwargs)

    async def patch(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self._request("PATCH", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return await self._request("DELETE", path, **kwargs)
