from pydantic import BaseSettings, Field


class Settings(BaseSettings):
    app_port: int = Field(default=8000, alias="APP_PORT")
    clockify_api_base_url: str = Field(default="https://api.clockify.me", alias="CLOCKIFY_API_BASE_URL")
    db_url: str = Field(default="sqlite+aiosqlite:///./api_studio.db", alias="API_STUDIO_DB_URL")

    bootstrap_max_rps: int = Field(default=25, alias="API_STUDIO_BOOTSTRAP_MAX_RPS")
    bootstrap_include_heavy_endpoints: bool = Field(
        default=False, alias="API_STUDIO_BOOTSTRAP_INCLUDE_HEAVY_ENDPOINTS"
    )

    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
