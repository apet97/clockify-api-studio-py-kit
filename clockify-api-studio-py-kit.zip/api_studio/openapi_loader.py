from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List

import json


@lru_cache(maxsize=1)
def load_openapi() -> Dict[str, Any]:
    """Load the Clockify OpenAPI spec bundled in docs/openapi.json.

    Claude: you can extend this to precompute an index of operations and tags.
    """
    path = Path(__file__).resolve().parents[1] / "docs" / "openapi.json"
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def list_safe_get_operations() -> List[Dict[str, Any]]:
    """Return a list of GET operations considered safe for bootstrap.

    The product spec defines what "safe" means (workspace-level list endpoints).
    Implement filtering here using the loaded OpenAPI spec.
    """
    spec = load_openapi()
    safe_ops: List[Dict[str, Any]] = []
    paths = spec.get("paths", {})
    for path, methods in paths.items():
        get_op = methods.get("get")
        if not get_op:
            continue
        # Claude: add logic to filter by workspaceId path param, avoid heavy reports, etc.
        safe_ops.append({"path": path, "operation": get_op})
    return safe_ops
