from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from .db import get_session
from .models import Installation

router = APIRouter(prefix="/lifecycle", tags=["lifecycle"])


@router.post("/installed")
async def lifecycle_installed(payload: dict, session: AsyncSession = Depends(get_session)) -> dict:
    """Handle Clockify add-on installation.

    Claude: validate payload according to Clockify_Addon_Guide, then:
    - Upsert Installation row for workspaceId.
    - Store addon token, apiUrl, settings.
    - Mark as active.
    - Kick off bootstrap job (can be deferred or background task).
    """
    # TODO: implement installation logic, X-Addon-Token extraction, etc.
    _ = (payload, session)
    return {"status": "ok"}


@router.post("/uninstalled")
async def lifecycle_uninstalled(payload: dict, session: AsyncSession = Depends(get_session)) -> dict:
    """Handle Clockify add-on uninstallation.

    Claude: mark installation inactive and optionally clean up data.
    """
    _ = (payload, session)
    return {"status": "ok"}


@router.post("/settings-updated")
async def lifecycle_settings_updated(payload: dict, session: AsyncSession = Depends(get_session)) -> dict:
    """Handle structured settings updates from Clockify.

    Claude: persist changes to Installation.settings_json and adjust behavior accordingly.
    """
    _ = (payload, session)
    return {"status": "ok"}
