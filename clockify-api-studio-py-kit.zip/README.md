# Clockify API Studio – Python Add-on Backend

This repository (or folder) is prepared for a **Python-based Clockify add-on** called
**Clockify API Studio**.

Clockify will call this service over HTTP using the manifest in `manifest.api-studio.json`.

The goal is:
- Receive Clockify webhooks and log them.
- Bootstrap workspace context by calling safe GET endpoints from the Clockify API.
- Provide a backend for a no-code API Explorer.
- Provide a small rules/flow engine that maps webhooks → API calls.

The detailed product spec is in `docs/clockify-api-studio-spec.md`.
All Python code lives under the `api_studio/` package.
