# Config Notes – Clockify API Studio (Python)

Main environment variables:

- APP_PORT: port to run FastAPI on (default 8000).
- CLOCKIFY_API_BASE_URL: base URL for Clockify API (default https://api.clockify.me).
- API_STUDIO_DB_URL: DB URL for SQLAlchemy (sqlite+aiosqlite:///./api_studio.db by default).
- API_STUDIO_BOOTSTRAP_MAX_RPS: max RPS per workspace for bootstrap (default 25).
- API_STUDIO_BOOTSTRAP_INCLUDE_HEAVY_ENDPOINTS: include heavy reports in bootstrap (default false).

Installation data (workspaceId, addonId, apiUrl, X-Addon-Token, settings) is stored in the database
and used to configure the Clockify client per workspace.
