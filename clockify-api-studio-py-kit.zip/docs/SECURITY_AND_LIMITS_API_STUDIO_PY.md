# Security & Limits – Clockify API Studio (Python)

- Never log or expose X-Addon-Token or DB passwords.
- All models include workspace_id and all queries filter by workspace_id.
- Outbound HTTP calls:
  - Only to Clockify API (base URL from env/installation).
  - Only paths defined in docs/openapi.json.
- Rate limiting:
  - Default 25 RPS per workspace for bootstrap and flows.
  - Use exponential backoff with jitter on 429 responses.
- Webhooks and lifecycle endpoints must validate signatures/JWTs as per Clockify_Addon_Guide.
