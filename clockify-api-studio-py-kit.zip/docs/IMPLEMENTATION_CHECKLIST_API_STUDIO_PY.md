# Implementation Checklist – Clockify API Studio (Python)

1. Project setup
- [ ] Confirm `pyproject.toml` installs dependencies and app is importable.
- [ ] Create Alembic migrations for api_studio models.

2. Core infrastructure
- [ ] Implement config.py to read env vars and provide settings object.
- [ ] Implement db.py for async SQLAlchemy engine + session maker.
- [ ] Implement models.py with ORM models:
      Installation, BootstrapState, EntityCache, Flow, FlowExecution, WebhookLog.

3. Clockify client
- [ ] Implement clockify_client.py with:
      - Async HTTP client (httpx).
      - Methods to perform GET/POST/PUT/PATCH/DELETE against Clockify API.
      - Rate limiting and exponential backoff on 429.

4. Lifecycle endpoints (lifecycle.py)
- [ ] POST /lifecycle/installed
- [ ] POST /lifecycle/uninstalled
- [ ] POST /lifecycle/settings-updated
      - Persist installation data and settings.
      - Kick off bootstrap when needed.

5. Webhooks (webhooks.py)
- [ ] POST /webhooks/clockify: validate, log, and invoke flows.

6. Bootstrap (bootstrap.py)
- [ ] Implement logic to:
      - Load docs/openapi.json.
      - Discover safe GET endpoints.
      - Fetch data with pagination and rate limiting.
      - Store into EntityCache and update BootstrapState.

7. API Explorer (api_explorer.py)
- [ ] GET /ui/api-explorer/endpoints: list operations from OpenAPI.
- [ ] POST /ui/api-explorer/execute: execute chosen operation via Clockify client.

8. Flows (flows.py)
- [ ] Flow CRUD endpoints under /ui/flows.
- [ ] Flow execution on webhooks with conditions and multiple actions.

9. UI (ui.py)
- [ ] Provide minimal JSON endpoints for Dashboard + status.
- [ ] Optionally serve static assets if a frontend is later added.

10. main.py
- [ ] Create FastAPI app, include routers, add health endpoints.
